import logo from './logo.svg';
import './App.css';
import QRCodeForm from './components/Qrcode';

function App() {
  return (
    <div className="App">
      <QRCodeForm/>
    </div>
  );
}

export default App;
